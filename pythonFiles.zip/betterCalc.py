try:
    num1 = float(input("Enter first number: "))
    num2 = float(input("Enter second number: "))
    operation = input("Enter operation (+, -, *, /): ")

    if operation == '+':
        result = num1 + num2
    elif operation == '-':
        result = num1 - num2
    elif operation == '*':
        result = num1 * num2
    elif operation == '/':
        result = num1 / num2    
    else:
        result = "Invalid operation"

except ZeroDivisionError:
    result = "Error: Cannot divide by zero."

except ValueError:
    result = "Invalid operation"

except Exception as e:
    result = f"Unexpected error: {e}"

print(f"Result: {result}")