students = [
    {'id': 'ENG001', 'name': 'Emma Watson', 'age': 19, 'course': 'Mechanical Engineering', 'year': 1},
    {'id': 'ENG002', 'name': 'James Smith', 'age': 20, 'course': 'Electrical Engineering', 'year': 2},
    {'id': 'ENG003', 'name': 'Olivia Brown', 'age': 21, 'course': 'Bio Engineering', 'year': 3}
]

modules = {
    'MECH101': {'name': 'Introduction to Thermodynamics', 'students': [], 'credits': 20},
    'ELEC201': {'name': 'Digital Systems Design', 'students': [], 'credits': 15},
    'CIVL301': {'name': 'Structural Analysis', 'students': [], 'credits': 20},
    'ENGR100': {'name': 'Engineering Mathematics', 'students': [], 'credits': 15}
}

def add_student(id, name, age, course, year):
    students.append({'id': id, 'name': name, 'age': age, 'course': course, 'year': year})
    print(f"Added student: {name} (ID: {id})")

def add_module(code, name, credits):
    modules[code] = {'name': name, 'students': [], 'credits': credits}
    print(f"Added module: {name} (Code: {code}, Credits: {credits})")

def display_students():
    print("\nStudent Directory:")
    for student in students:
        print(f"ID: {student['id']}, Name: {student['name']}, Age: {student['age']}, Course: {student['course']}, Year: {student['year']}")

def enrol_student(student_id, module_code):
    student = next((s for s in students if s['id'] == student_id), None)
    if not student:
        return f"Student ID {student_id} not found"
    
    if module_code not in modules:
        return f"Module code {module_code} not found"
    
    if student_id in modules[module_code]['students']:
        return f"{student['name']} is already enrolled in {modules[module_code]['name']}"
    
    modules[module_code]['students'].append(student_id)
    return f"Enrolled {student['name']} in {modules[module_code]['name']}"

def withdraw_from_module(student_id, module_code):
    if module_code not in modules:
        return f"Module code {module_code} not found"
    
    if student_id not in modules[module_code]['students']:
        return f"Student ID {student_id} is not enrolled in {modules[module_code]['name']}"
    
    modules[module_code]['students'].remove(student_id)
    student = next(s for s in students if s['id'] == student_id)
    return f"Withdrawn {student['name']} from {modules[module_code]['name']}"

def display_module_info(module_code):
    if module_code not in modules:
        return f"Module code {module_code} not found"
    
    module = modules[module_code]
    print(f"\nModule Information for {module['name']} (Code: {module_code}, Credits: {module['credits']}):")
    print("Enrolled students:")
    for student_id in module['students']:
        student = next(s for s in students if s['id'] == student_id)
        print(f"- {student['name']} (ID: {student['id']}, Course: {student['course']}, Year: {student['year']})")


add_student('ENG004', 'William Taylor', 18, 'Bio Engineering', 1)
add_module('CHEM102', 'Process Engineering Principles', 20)

display_students()

print(enrol_student('ENG001', 'MECH101'))  
print(enrol_student('ENG002', 'ELEC201'))  
print(enrol_student('ENG003', 'CIVL301'))  
print(enrol_student('ENG004', 'CHEM102'))  
print(enrol_student('ENG001', 'ENGR100'))  

print(withdraw_from_module('ENG002', 'ELEC201'))  

display_module_info('MECH101')
display_module_info('ENGR100')