phone_book = {
    "Alice": "01227 123456",
    "Bob": "01227 234567",
    "Charlie": "01227 345678"
}


def display_phone_book(book):
    print("Phone Book:")
    for name, number in book.items():
        print(f"{name}: {number}")

def add_contact(book, name, number):
    book[name] = number
    print(f"Added {name} to the phone book.")

def search_contact(book, name):
    if name in book:
        return f"{name}'s number is {book[name]}"
    else:
        return f"{name} not found in the phone book."


display_phone_book(phone_book)
print()

add_contact(phone_book, "David", "01227 456789")
print()

display_phone_book(phone_book)
print()

print(search_contact(phone_book, "Alice"))
print(search_contact(phone_book, "Eve"))