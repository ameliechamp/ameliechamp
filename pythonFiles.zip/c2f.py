celsius = 25.0  
fahrenheit = (celsius * 9/5) + 32  
result = f"{celsius}°C is equal to {fahrenheit:.1f}°F"  

print(result)  