def day_of_week(number):
    day = number % 7
    match day:
        case 0:
            return "Sunday"
        case 1:
            return "Monday"
        case 2:
            return "Tuesday"
        case 3:
            return "Wednesday"
        case 4:
            return "Thursday"
        case 5:
            return "Friday"
        case 6:
            return "Saturday"

# Test the function
for i in range(1, 15):
    print(f"Day {i}: {day_of_week(i)}")